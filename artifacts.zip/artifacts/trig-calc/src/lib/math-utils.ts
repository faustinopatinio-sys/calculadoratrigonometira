export function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

export function toDegrees(radians: number): number {
  return radians * (180 / Math.PI);
}

export function formatNumber(num: number, decimals: number = 4): string {
  if (Math.abs(num) < 1e-10) return "0";
  return Number(num.toFixed(decimals)).toString();
}

export function getExactValue(degrees: number): { sin: string, cos: string, tan: string } | null {
  const exactValues: Record<number, { sin: string, cos: string, tan: string }> = {
    0: { sin: "0", cos: "1", tan: "0" },
    30: { sin: "1/2", cos: "√3/2", tan: "√3/3" },
    45: { sin: "√2/2", cos: "√2/2", tan: "1" },
    60: { sin: "√3/2", cos: "1/2", tan: "√3" },
    90: { sin: "1", cos: "0", tan: "Indefinido" },
    120: { sin: "√3/2", cos: "-1/2", tan: "-√3" },
    135: { sin: "√2/2", cos: "-√2/2", tan: "-1" },
    150: { sin: "1/2", cos: "-√3/2", tan: "-√3/3" },
    180: { sin: "0", cos: "-1", tan: "0" },
    210: { sin: "-1/2", cos: "-√3/2", tan: "√3/3" },
    225: { sin: "-√2/2", cos: "-√2/2", tan: "1" },
    240: { sin: "-√3/2", cos: "-1/2", tan: "√3" },
    270: { sin: "-1", cos: "0", tan: "Indefinido" },
    300: { sin: "-√3/2", cos: "1/2", tan: "-√3" },
    315: { sin: "-√2/2", cos: "√2/2", tan: "-1" },
    330: { sin: "-1/2", cos: "√3/2", tan: "-√3/3" },
    360: { sin: "0", cos: "1", tan: "0" }
  };
  
  const normalizedDeg = ((degrees % 360) + 360) % 360;
  return exactValues[normalizedDeg] || null;
}
