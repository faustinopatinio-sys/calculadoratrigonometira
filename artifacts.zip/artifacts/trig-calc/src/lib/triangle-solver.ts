export type TriangleType = "SSS" | "SAS" | "AAS" | "ASA" | "SSA";

export interface TriangleInput {
  type: TriangleType;
  a?: number;
  b?: number;
  c?: number;
  A?: number; // degrees
  B?: number; // degrees
  C?: number; // degrees
}

export interface TriangleResult {
  a: number;
  b: number;
  c: number;
  A: number;
  B: number;
  C: number;
  steps: { id: number; title: string; content: string }[];
  isAmbiguous?: boolean;
  altTriangle?: Omit<TriangleResult, "steps" | "isAmbiguous" | "altTriangle">;
  noSolution?: boolean;
}

const deg2rad = (deg: number) => deg * (Math.PI / 180);
const rad2deg = (rad: number) => rad * (180 / Math.PI);
const format = (n: number) => Number(n.toFixed(2));

export function solveTriangle(input: TriangleInput): TriangleResult {
  let steps: any[] = [];
  let a = input.a || 0;
  let b = input.b || 0;
  let c = input.c || 0;
  let A = input.A || 0;
  let B = input.B || 0;
  let C = input.C || 0;

  if (input.type === "SSS") {
    // Law of Cosines
    steps.push({
      id: 1, title: "Paso 1: Ley de Cosenos para encontrar el ángulo A",
      content: `Usamos a² = b² + c² - 2bc*cos(A) \ncos(A) = (b² + c² - a²) / 2bc \nA = arccos((${b}² + ${c}² - ${a}²) / (2*${b}*${c}))`
    });
    const cosA = (b*b + c*c - a*a) / (2*b*c);
    if (cosA < -1 || cosA > 1) return { a, b, c, A, B, C, steps: [{ id: 1, title: "Error", content: "El triángulo no existe." }], noSolution: true };
    A = format(rad2deg(Math.acos(cosA)));
    
    steps.push({
      id: 2, title: "Paso 2: Ley de Senos para encontrar el ángulo B",
      content: `Usamos sin(A)/a = sin(B)/b \nsin(B) = (b * sin(A)) / a \nB = arcsin((${b} * sin(${A}°)) / ${a})`
    });
    const sinB = (b * Math.sin(deg2rad(A))) / a;
    B = format(rad2deg(Math.asin(sinB)));

    steps.push({
      id: 3, title: "Paso 3: Ángulo C",
      content: `La suma de ángulos es 180° \nC = 180° - A - B \nC = 180° - ${A}° - ${B}°`
    });
    C = format(180 - A - B);
  }

  // Handle other types SAS, ASA, AAS, SSA (simplified for demo)
  // ... omitting full implementation for brevity, just handling basic fallback
  if (input.type !== "SSS") {
    steps.push({ id: 1, title: "Info", content: "Implementación completa pendiente para este caso." });
  }

  return { a, b, c, A, B, C, steps };
}
