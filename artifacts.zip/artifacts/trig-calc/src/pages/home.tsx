import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { FunctionSquare, Triangle, Brackets, ArrowRight, BookOpen } from "lucide-react";
import { motion } from "framer-motion";

const modules = [
  {
    title: "Razones Trigonométricas",
    description: "sin, cos, tan y sus inversas. Pasos detallados, valores exactos y cuadrante.",
    icon: FunctionSquare,
    href: "/razones",
    accent: "from-emerald-500/20 to-green-500/10 border-emerald-500/30",
    iconColor: "text-emerald-400",
    iconBg: "bg-emerald-500/15",
    tag: "6 razones",
  },
  {
    title: "Identidades Trigonométricas",
    description: "Verifica ambos lados de una identidad paso a paso. Pitagóricas, doble ángulo, recíprocas.",
    icon: Brackets,
    href: "/identidades",
    accent: "from-teal-500/20 to-emerald-500/10 border-teal-500/30",
    iconColor: "text-teal-400",
    iconBg: "bg-teal-500/15",
    tag: "13 identidades",
  },
  {
    title: "Resolución de Triángulos",
    description: "Resuelve cualquier triángulo con Ley de Senos y Cosenos. Gráfico SVG incluido.",
    icon: Triangle,
    href: "/triangulos",
    accent: "from-green-500/20 to-teal-500/10 border-green-500/30",
    iconColor: "text-green-400",
    iconBg: "bg-green-500/15",
    tag: "SSS · SAS · AAS · ASA · SSA",
  },
  {
    title: "Ejercicios",
    description: "Genera ejercicios aleatorios y visualiza el desarrollo completo con despejes paso a paso.",
    icon: BookOpen,
    href: "/ejercicios",
    accent: "from-lime-500/20 to-green-500/10 border-lime-500/30",
    iconColor: "text-lime-400",
    iconBg: "bg-lime-500/15",
    tag: "4 tipos",
  },
];

const floatingSymbols = [
  { symbol: "sin θ", x: "8%",  y: "15%", size: "text-2xl", delay: 0 },
  { symbol: "cos θ", x: "88%", y: "12%", size: "text-xl",  delay: 0.4 },
  { symbol: "tan θ", x: "5%",  y: "72%", size: "text-xl",  delay: 0.8 },
  { symbol: "π",     x: "92%", y: "65%", size: "text-4xl", delay: 0.2 },
  { symbol: "θ",     x: "50%", y: "5%",  size: "text-5xl", delay: 0.6 },
  { symbol: "√2",    x: "75%", y: "80%", size: "text-2xl", delay: 1.0 },
  { symbol: "∑",     x: "15%", y: "45%", size: "text-3xl", delay: 0.3 },
  { symbol: "∞",     x: "85%", y: "40%", size: "text-3xl", delay: 0.7 },
  { symbol: "α",     x: "30%", y: "88%", size: "text-2xl", delay: 0.5 },
  { symbol: "β",     x: "62%", y: "92%", size: "text-xl",  delay: 0.9 },
];

export default function Home() {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-10">

        <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-card via-card/80 to-primary/5 py-14 px-6">
          {floatingSymbols.map((s, i) => (
            <motion.span
              key={i}
              className={`absolute font-mono font-bold text-primary/10 select-none pointer-events-none ${s.size}`}
              style={{ left: s.x, top: s.y }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: [10, -6, 10] }}
              transition={{
                opacity: { delay: s.delay, duration: 0.6 },
                y: { delay: s.delay, duration: 4 + i * 0.3, repeat: Infinity, ease: "easeInOut" },
              }}
            >
              {s.symbol}
            </motion.span>
          ))}

          <div className="relative text-center space-y-4 z-10">
            <motion.div
              initial={{ opacity: 0, y: -16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="inline-block bg-primary/15 text-primary text-xs font-semibold tracking-widest uppercase px-4 py-1 rounded-full border border-primary/20 mb-4">
                Calculadora Trigonométrica
              </span>
            </motion.div>

            <motion.h1
              className="text-4xl md:text-6xl font-black tracking-tight text-foreground"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              Calc<span className="text-primary">Trig</span>
            </motion.h1>

            <motion.p
              className="text-lg md:text-xl text-muted-foreground max-w-xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              Resuelve trigonometría paso a paso. Razones, identidades, triángulos y ejercicios — todo con desarrollo completo.
            </motion.p>

            <motion.div
              className="flex flex-wrap gap-3 justify-center pt-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.35 }}
            >
              {["Pasos detallados", "Valores exactos", "Despejes explicados", "Sin publicidad"].map((badge) => (
                <span key={badge} className="text-xs bg-primary/10 text-primary border border-primary/20 px-3 py-1 rounded-full font-medium">
                  {badge}
                </span>
              ))}
            </motion.div>
          </div>
        </div>

        <div>
          <motion.p
            className="text-xs text-muted-foreground uppercase tracking-widest font-semibold mb-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Módulos disponibles
          </motion.p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {modules.map((mod, index) => {
              const Icon = mod.icon;
              return (
                <motion.div
                  key={mod.href}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.45 + index * 0.08 }}
                >
                  <Link href={mod.href}>
                    <Card className={`h-full cursor-pointer group transition-all duration-200 bg-gradient-to-br hover:shadow-lg hover:shadow-primary/10 hover:-translate-y-0.5 border ${mod.accent}`}>
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between mb-3">
                          <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${mod.iconBg}`}>
                            <Icon className={`w-5 h-5 ${mod.iconColor}`} />
                          </div>
                          <span className="text-xs text-muted-foreground bg-card/60 border border-border/50 rounded-full px-2 py-0.5 font-mono">
                            {mod.tag}
                          </span>
                        </div>
                        <CardTitle className="text-base group-hover:text-primary transition-colors duration-150">
                          {mod.title}
                        </CardTitle>
                        <CardDescription className="text-sm leading-relaxed">
                          {mod.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="flex items-center gap-1 text-xs font-semibold text-primary opacity-0 group-hover:opacity-100 transition-all duration-200 -translate-x-1 group-hover:translate-x-0">
                          Abrir módulo <ArrowRight className="w-3 h-3" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-3"
        >
          {[
            { n: "13", label: "Identidades" },
            { n: "4",  label: "Tipos de ejercicios" },
            { n: "5",  label: "Casos de triángulos" },
            { n: "6",  label: "Razones trigonométricas" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="rounded-xl border border-primary/15 bg-card/50 px-4 py-4 text-center"
            >
              <div className="text-2xl font-black text-primary">{stat.n}</div>
              <div className="text-xs text-muted-foreground mt-0.5 leading-tight">{stat.label}</div>
            </div>
          ))}
        </motion.div>

      </div>
    </Layout>
  );
}
