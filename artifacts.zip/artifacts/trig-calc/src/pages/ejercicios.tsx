import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toRadians, formatNumber, getExactValue } from "@/lib/math-utils";
import { RefreshCw, Eye, CheckCircle, ChevronRight } from "lucide-react";

const fmt = (n: number, d = 4) => formatNumber(n, d);
const frac = (n: number, d: number) => d === 1 ? `${n}` : `${n}/${d}`;

// ─── Types ──────────────────────────────────────────────────────────────────

type ExerciseType = "contextual" | "doble-angulo" | "cuadrante" | "simplificacion";

interface Step {
  title: string;
  lines: string[];
  despeje?: string;
}

interface GeneratedExercise {
  type: ExerciseType;
  problem: string;
  enunciado: string;
  contexto?: string;
  given: { label: string; value: string }[];
  find: string[];
  steps: Step[];
  respuesta: { label: string; value: string }[];
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function randomOf<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}
function randomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ─── Generator 1: Problemas contextuales reales ──────────────────────────────
// Randomly picks one of 4 real-world scenarios each time

function genContextual(): GeneratedExercise {
  const scenario = randomOf(["escalera", "edificio", "avion", "sombra"] as const);

  if (scenario === "escalera") {
    const angle = randomOf([30, 40, 45, 50, 60, 65, 70]);
    const len = randomInt(3, 15);
    const rad = toRadians(angle);
    const exact = getExactValue(angle);
    const sinStr = exact?.sin ?? fmt(Math.sin(rad));
    const cosStr = exact?.cos ?? fmt(Math.cos(rad));
    const height = fmt(len * Math.sin(rad));
    const base   = fmt(len * Math.cos(rad));
    return {
      type: "contextual",
      problem: `Una escalera de ${len} m forma un ángulo de ${angle}° con el suelo. ¿Qué altura alcanza en la pared?`,
      enunciado: `Una escalera de ${len} m de longitud se apoya contra una pared vertical, formando un ángulo de ${angle}° con el suelo. Calcula la altura (h) que alcanza en la pared y la distancia (d) desde la base de la pared al pie de la escalera.`,
      contexto: "Problema de ángulo de elevación — triángulo rectángulo formado por la escalera, la pared y el suelo.",
      given: [
        { label: "Longitud escalera (c)", value: `${len} m` },
        { label: "Ángulo con el suelo (α)", value: `${angle}°` },
      ],
      find: ["h — altura en la pared", "d — distancia al pie"],
      steps: [
        {
          title: "Paso 1 — Identificar el triángulo rectángulo",
          lines: [
            `La escalera (c = ${len} m) es la hipotenusa.`,
            `La pared forma el cateto opuesto (h).`,
            `El suelo forma el cateto adyacente (d).`,
            `El ángulo α = ${angle}° está entre la escalera y el suelo.`,
          ],
        },
        {
          title: "Paso 2 — Despejar la altura h",
          lines: [
            `Relación:  sin(α) = cateto opuesto / hipotenusa = h / c`,
            ``,
            `Despejar h multiplicando por c:`,
            `  h = c · sin(α)`,
            `  h = ${len} · sin(${angle}°)`,
            `  h = ${len} · ${sinStr}`,
            `  h = ${height} m`,
          ],
          despeje: `sin(α) = h / c  ⟹  h = c · sin(α)`,
        },
        {
          title: "Paso 3 — Despejar la distancia horizontal d",
          lines: [
            `Relación:  cos(α) = cateto adyacente / hipotenusa = d / c`,
            ``,
            `Despejar d:`,
            `  d = c · cos(α)`,
            `  d = ${len} · cos(${angle}°)`,
            `  d = ${len} · ${cosStr}`,
            `  d = ${base} m`,
          ],
          despeje: `cos(α) = d / c  ⟹  d = c · cos(α)`,
        },
        {
          title: "Paso 4 — Verificación con Teorema de Pitágoras",
          lines: [
            `h² + d² debe ser igual a c²`,
            `${height}² + ${base}² ≈ ${fmt(len * len)}`,
            `c² = ${len}² = ${len * len}  ✓`,
          ],
        },
      ],
      respuesta: [
        { label: "h (altura)", value: `${height} m` },
        { label: "d (base)", value: `${base} m` },
      ],
    };
  }

  if (scenario === "edificio") {
    const angle = randomOf([25, 30, 35, 40, 45, 50, 60]);
    const dist = randomInt(8, 40);
    const rad = toRadians(angle);
    const exact = getExactValue(angle);
    const tanStr = exact?.tan ?? fmt(Math.tan(rad));
    const height = fmt(dist * Math.tan(rad));
    return {
      type: "contextual",
      problem: `Desde ${dist} m de un edificio el ángulo de elevación a su cima es ${angle}°. ¿Cuánto mide el edificio?`,
      enunciado: `Un observador está parado a ${dist} m (en horizontal) de la base de un edificio. El ángulo de elevación desde sus ojos hasta la cima del edificio es de ${angle}°. Calcula la altura del edificio (h).`,
      contexto: "Ángulo de elevación — el observador mira hacia arriba con ángulo α desde la horizontal.",
      given: [
        { label: "Distancia horizontal (d)", value: `${dist} m` },
        { label: "Ángulo de elevación (α)", value: `${angle}°` },
      ],
      find: ["h — altura del edificio"],
      steps: [
        {
          title: "Paso 1 — Plantear el triángulo rectángulo",
          lines: [
            `El cateto adyacente es la distancia horizontal: d = ${dist} m`,
            `El cateto opuesto es la altura desconocida: h = ?`,
            `El ángulo de elevación α = ${angle}° es el ángulo en la base.`,
          ],
        },
        {
          title: "Paso 2 — Elegir la razón trigonométrica adecuada",
          lines: [
            `Tenemos el cateto adyacente (d) y buscamos el cateto opuesto (h).`,
            `La razón que relaciona opuesto con adyacente es la TANGENTE:`,
            `  tan(α) = cateto opuesto / cateto adyacente = h / d`,
          ],
        },
        {
          title: "Paso 3 — Despejar h",
          lines: [
            `tan(α) = h / d`,
            ``,
            `Multiplicar ambos lados por d:`,
            `  h = d · tan(α)`,
            `  h = ${dist} · tan(${angle}°)`,
            `  h = ${dist} · ${tanStr}`,
            `  h = ${height} m`,
          ],
          despeje: `tan(α) = h / d  ⟹  h = d · tan(α)`,
        },
      ],
      respuesta: [{ label: "h (altura del edificio)", value: `${height} m` }],
    };
  }

  if (scenario === "avion") {
    const depress = randomOf([20, 25, 30, 35, 40, 45]);
    const altitud = randomInt(500, 5000);
    const rad = toRadians(depress);
    const exact = getExactValue(depress);
    const tanStr = exact?.tan ?? fmt(Math.tan(rad));
    const dist = fmt(altitud / Math.tan(rad));
    return {
      type: "contextual",
      problem: `Un avión vuela a ${altitud} m de altitud. El ángulo de depresión al aeropuerto es ${depress}°. ¿A qué distancia horizontal está?`,
      enunciado: `Un avión vuela a ${altitud} m de altura. El piloto observa el aeropuerto con un ángulo de depresión de ${depress}° (ángulo hacia abajo desde la horizontal). ¿Cuántos metros de distancia horizontal faltan para llegar al aeropuerto?`,
      contexto: "Ángulo de depresión — el piloto mira hacia abajo. El ángulo de depresión = ángulo de elevación desde el suelo.",
      given: [
        { label: "Altitud del avión (h)", value: `${altitud} m` },
        { label: "Ángulo de depresión (β)", value: `${depress}°` },
      ],
      find: ["d — distancia horizontal al aeropuerto"],
      steps: [
        {
          title: "Paso 1 — Identificar la geometría",
          lines: [
            `El avión está a h = ${altitud} m de altura (cateto opuesto al ángulo β).`,
            `La distancia horizontal d es el cateto adyacente.`,
            `Propiedad: el ángulo de depresión = ángulo de elevación desde el suelo = β = ${depress}°`,
          ],
        },
        {
          title: "Paso 2 — Plantear con tangente",
          lines: [
            `tan(β) = cateto opuesto / cateto adyacente`,
            `tan(${depress}°) = h / d = ${altitud} / d`,
          ],
        },
        {
          title: "Paso 3 — Despejar la distancia horizontal d",
          lines: [
            `tan(β) = h / d`,
            ``,
            `Multiplicar ambos lados por d:`,
            `  d · tan(β) = h`,
            ``,
            `Dividir ambos lados por tan(β):`,
            `  d = h / tan(β)`,
            `  d = ${altitud} / tan(${depress}°)`,
            `  d = ${altitud} / ${tanStr}`,
            `  d = ${dist} m`,
          ],
          despeje: `tan(β) = h/d  ⟹  d = h / tan(β)`,
        },
      ],
      respuesta: [{ label: "d (distancia horizontal)", value: `${dist} m` }],
    };
  }

  // sombra
  const treeHeight = randomInt(3, 20);
  const shadowLen  = randomInt(2, treeHeight);
  const rad = Math.atan(treeHeight / shadowLen);
  const deg = fmt(rad * 180 / Math.PI);
  return {
    type: "contextual",
    problem: `Un árbol de ${treeHeight} m proyecta una sombra de ${shadowLen} m. ¿Cuál es el ángulo de elevación del sol?`,
    enunciado: `Un árbol de ${treeHeight} m de altura proyecta una sombra de ${shadowLen} m sobre el suelo plano. Calcula el ángulo de elevación del sol α.`,
    contexto: "La altura del árbol es el cateto opuesto; la sombra es el cateto adyacente. Hay que despejar el ángulo.",
    given: [
      { label: "Altura del árbol (h)", value: `${treeHeight} m` },
      { label: "Longitud de la sombra (d)", value: `${shadowLen} m` },
    ],
    find: ["α — ángulo de elevación del sol"],
    steps: [
      {
        title: "Paso 1 — Identificar la razón que relaciona los datos",
        lines: [
          `Cateto opuesto al ángulo α = altura del árbol = ${treeHeight} m`,
          `Cateto adyacente al ángulo α = sombra = ${shadowLen} m`,
          `La razón que relaciona opuesto y adyacente es la TANGENTE.`,
        ],
      },
      {
        title: "Paso 2 — Plantear la ecuación",
        lines: [
          `tan(α) = cateto opuesto / cateto adyacente`,
          `tan(α) = ${treeHeight} / ${shadowLen}`,
          `tan(α) = ${fmt(treeHeight / shadowLen)}`,
        ],
      },
      {
        title: "Paso 3 — Despejar α aplicando arctan",
        lines: [
          `tan(α) = ${fmt(treeHeight / shadowLen)}`,
          ``,
          `Aplicar arctan a ambos lados:`,
          `  arctan[tan(α)] = arctan(${fmt(treeHeight / shadowLen)})`,
          `  α = arctan(${fmt(treeHeight / shadowLen)})`,
          `  α ≈ ${deg}°`,
        ],
        despeje: `tan(α) = op/adj  ⟹  α = arctan(op/adj)`,
      },
    ],
    respuesta: [{ label: "α (ángulo de elevación)", value: `${deg}°` }],
  };
}

// ─── Generator 2: Doble ángulo ───────────────────────────────────────────────
// Given sin or cos as a nice fraction, find sin(2θ), cos(2θ), tan(2θ)

const PYTHAGOREAN_TRIPLES = [
  { p: 3, q: 5 },   // sin=3/5, cos=4/5
  { p: 4, q: 5 },   // sin=4/5, cos=3/5
  { p: 5, q: 13 },  // sin=5/13, cos=12/13
  { p: 12, q: 13 }, // sin=12/13, cos=5/13
  { p: 8, q: 17 },  // sin=8/17, cos=15/17
  { p: 7, q: 25 },  // sin=7/25, cos=24/25
];

function genDobleAngulo(): GeneratedExercise {
  const triple = randomOf(PYTHAGOREAN_TRIPLES);
  const { p, q } = triple;
  const adj = Math.round(Math.sqrt(q * q - p * p));

  // Randomly give sin or cos
  const giveSin = Math.random() < 0.5;
  const sinN = giveSin ? p : adj;
  const cosN = giveSin ? adj : p;
  const sinD = q, cosD = q;

  const sinStr = frac(sinN, sinD);
  const cosStr = frac(cosN, cosD);

  // sin(2θ) = 2sin cos
  const sin2N = 2 * sinN * cosN;
  const sin2D = q * q;
  const gcdSin2 = gcd(sin2N, sin2D);
  const sin2Str = frac(sin2N / gcdSin2, sin2D / gcdSin2);

  // cos(2θ) = cos² - sin²
  const cos2N = cosN * cosN - sinN * sinN;
  const cos2D = q * q;
  const gcdCos2 = gcd(Math.abs(cos2N), cos2D);
  const cos2Str = frac(cos2N / gcdCos2, cos2D / gcdCos2);

  // tan(2θ) = sin(2θ)/cos(2θ)
  const tan2N = sin2N / gcdSin2;
  const tan2D_raw = sin2D / gcdSin2;
  const cos2_n = cos2N / gcdCos2;
  const cos2_d = cos2D / gcdCos2;
  // tan2 = (tan2N/tan2D_raw) / (cos2_n/cos2_d) = (tan2N * cos2_d) / (tan2D_raw * cos2_n)
  const tan2Num = tan2N * cos2_d;
  const tan2Den = tan2D_raw * cos2_n;
  const gcdTan = gcd(Math.abs(tan2Num), Math.abs(tan2Den));
  const tan2Str = cos2N === 0 ? "indefinido" : frac(tan2Num / gcdTan, tan2Den / gcdTan);

  const knownFn = giveSin ? "sin" : "cos";
  const knownVal = giveSin ? sinStr : cosStr;

  return {
    type: "doble-angulo",
    problem: `Dado ${knownFn}(θ) = ${knownVal} (1er cuadrante), calcula sin(2θ), cos(2θ) y tan(2θ)`,
    enunciado: `Se sabe que ${knownFn}(θ) = ${knownVal} con θ en el primer cuadrante. Usa las fórmulas de ángulo doble para calcular sin(2θ), cos(2θ) y tan(2θ).`,
    given: [
      { label: `${knownFn}(θ)`, value: knownVal },
      { label: "Cuadrante", value: "I" },
    ],
    find: ["sin(2θ)", "cos(2θ)", "tan(2θ)"],
    steps: [
      {
        title: `Paso 1 — Hallar ${giveSin ? "cos(θ)" : "sin(θ)"} con la identidad pitagórica`,
        lines: [
          `Identidad:  sin²(θ) + cos²(θ) = 1`,
          ``,
          `${giveSin
            ? `sin²(θ) = (${sinStr})² = ${sinN}²/${sinD}² = ${sinN * sinN}/${sinD * sinD}`
            : `cos²(θ) = (${cosStr})² = ${cosN}²/${cosD}² = ${cosN * cosN}/${cosD * cosD}`
          }`,
          ``,
          `${giveSin
            ? `cos²(θ) = 1 − ${sinN * sinN}/${sinD * sinD} = ${sinD * sinD - sinN * sinN}/${sinD * sinD}`
            : `sin²(θ) = 1 − ${cosN * cosN}/${cosD * cosD} = ${cosD * cosD - cosN * cosN}/${cosD * cosD}`
          }`,
          ``,
          `Como θ está en el cuadrante I, ${giveSin ? "cos" : "sin"}(θ) > 0:`,
          `${giveSin
            ? `  cos(θ) = √(${adj * adj}/${q * q}) = ${adj}/${q} = ${cosStr}`
            : `  sin(θ) = √(${adj * adj}/${q * q}) = ${adj}/${q} = ${sinStr}`
          }`,
        ],
        despeje: `${giveSin ? "cos" : "sin"}(θ) = √(1 − ${knownFn}²(θ))`,
      },
      {
        title: "Paso 2 — Calcular sin(2θ) con fórmula de ángulo doble",
        lines: [
          `Fórmula:  sin(2θ) = 2 · sin(θ) · cos(θ)`,
          ``,
          `sin(2θ) = 2 · (${sinStr}) · (${cosStr})`,
          `sin(2θ) = 2 · ${sinN}/${sinD} · ${cosN}/${cosD}`,
          `sin(2θ) = ${2 * sinN * cosN} / ${sinD * cosD}`,
          `sin(2θ) = ${sin2Str}`,
        ],
        despeje: `sin(2θ) = 2·sin(θ)·cos(θ)`,
      },
      {
        title: "Paso 3 — Calcular cos(2θ)",
        lines: [
          `Fórmula:  cos(2θ) = cos²(θ) − sin²(θ)`,
          ``,
          `cos(2θ) = (${cosStr})² − (${sinStr})²`,
          `cos(2θ) = ${cosN * cosN}/${cosD * cosD} − ${sinN * sinN}/${sinD * sinD}`,
          `cos(2θ) = (${cosN * cosN} − ${sinN * sinN}) / ${q * q}`,
          `cos(2θ) = ${cos2N}/${cos2D}`,
          `cos(2θ) = ${cos2Str}`,
        ],
        despeje: `cos(2θ) = cos²(θ) − sin²(θ)`,
      },
      {
        title: "Paso 4 — Calcular tan(2θ)",
        lines: [
          `Fórmula:  tan(2θ) = sin(2θ) / cos(2θ)`,
          ``,
          `tan(2θ) = (${sin2Str}) / (${cos2Str})`,
          `tan(2θ) = ${tan2Str}`,
        ],
        despeje: `tan(2θ) = sin(2θ) / cos(2θ)`,
      },
    ],
    respuesta: [
      { label: "sin(2θ)", value: sin2Str },
      { label: "cos(2θ)", value: cos2Str },
      { label: "tan(2θ)", value: tan2Str },
    ],
  };
}

function gcd(a: number, b: number): number {
  return b === 0 ? a : gcd(b, a % b);
}

// ─── Generator 3: Cuadrante y signos ─────────────────────────────────────────
// Given one trig ratio and quadrant info (not Q1), find the rest

interface QuadrantCase {
  fn: string;
  n: number;
  d: number;
  q: number;
  qLabel: string;
}

const QUADRANT_CASES: QuadrantCase[] = [
  { fn: "sin",  n:  3, d: 5,  q: 2, qLabel: "segundo (II)  →  sin > 0, cos < 0, tan < 0" },
  { fn: "cos",  n: -4, d: 5,  q: 2, qLabel: "segundo (II)  →  sin > 0, cos < 0, tan < 0" },
  { fn: "tan",  n: -1, d: 1,  q: 4, qLabel: "cuarto (IV)   →  sin < 0, cos > 0, tan < 0" },
  { fn: "sin",  n: -5, d: 13, q: 3, qLabel: "tercer (III)  →  sin < 0, cos < 0, tan > 0" },
  { fn: "cos",  n: -3, d: 5,  q: 3, qLabel: "tercer (III)  →  sin < 0, cos < 0, tan > 0" },
  { fn: "cos",  n:  4, d: 5,  q: 4, qLabel: "cuarto (IV)   →  sin < 0, cos > 0, tan < 0" },
  { fn: "tan",  n:  5, d: 12, q: 3, qLabel: "tercer (III)  →  sin < 0, cos < 0, tan > 0" },
  { fn: "sin",  n: -12, d: 13, q: 3, qLabel: "tercer (III) →  sin < 0, cos < 0, tan > 0" },
];

function genCuadrante(): GeneratedExercise {
  const c = randomOf(QUADRANT_CASES);
  const { fn, n, d, q, qLabel } = c;
  const valStr = `${n < 0 ? "−" : ""}${frac(Math.abs(n), d)}`;

  // Derive sin, cos, tan from whatever is given
  let sinN: number, cosN: number;

  if (fn === "sin") {
    sinN = n;
    const rest = Math.round(Math.sqrt(d * d - n * n));
    cosN = (q === 2 || q === 3) ? -rest : rest;
  } else if (fn === "cos") {
    cosN = n;
    const rest = Math.round(Math.sqrt(d * d - n * n));
    sinN = (q === 3 || q === 4) ? -rest : rest;
  } else {
    // tan given: reconstruct using pythagorean
    // tan = n/1 means opp=|n|, adj=1, hyp=√(n²+1)
    // But here we always use standard triples; hardcode some
    if (Math.abs(n) === 1) {
      sinN = q === 4 ? -1 : 1;
      cosN = q === 4 ? 1 : -1;
    } else if (n === 5 && d === 12) {
      sinN = -5; cosN = -12;
    } else {
      sinN = -n; cosN = -d;
    }
  }
  const hyp = d;
  const sinStr = `${sinN < 0 ? "−" : ""}${frac(Math.abs(sinN), hyp)}`;
  const cosStr = `${cosN < 0 ? "−" : ""}${frac(Math.abs(cosN), hyp)}`;
  const tanVal = sinN / cosN;
  const tanG = gcd(Math.abs(sinN), Math.abs(cosN));
  const tNum = sinN / tanG, tDen = cosN / tanG;
  const tanStr = tDen === 1 ? `${tNum}` : `${tNum < 0 ? "−" : ""}${frac(Math.abs(tNum), Math.abs(tDen))}`;

  const qRom = ["", "I","II","III","IV"][q];

  const pythStep = fn === "sin"
    ? [`cos²(θ) = 1 − sin²(θ) = 1 − (${valStr})² = 1 − ${n*n}/${d*d} = ${d*d - n*n}/${d*d}`,
       `|cos(θ)| = √(${d*d - n*n}/${d*d}) = ${Math.round(Math.sqrt(d*d - n*n))}/${d}`,
       `En el cuadrante ${qRom}: cos(θ) ${cosN < 0 ? "< 0  →  cos(θ) = " + cosStr : "> 0  →  cos(θ) = " + cosStr}`]
    : fn === "cos"
    ? [`sin²(θ) = 1 − cos²(θ) = 1 − (${valStr})² = 1 − ${n*n}/${d*d} = ${d*d - n*n}/${d*d}`,
       `|sin(θ)| = √(${d*d - n*n}/${d*d}) = ${Math.round(Math.sqrt(d*d - n*n))}/${d}`,
       `En el cuadrante ${qRom}: sin(θ) ${sinN < 0 ? "< 0  →  sin(θ) = " + sinStr : "> 0  →  sin(θ) = " + sinStr}`]
    : [`tan(θ) = sin(θ)/cos(θ) = ${valStr}`,
       `Plantear: sin(θ) = ${Math.abs(sinN)}k,  cos(θ) = ${Math.abs(cosN)}k`,
       `Por identidad pitagórica: sin²+cos² = 1  →  (${Math.abs(sinN)}k)² + (${Math.abs(cosN)}k)² = 1`,
       `k² (${sinN*sinN + cosN*cosN}) = 1  →  k = 1/${Math.round(Math.sqrt(sinN*sinN + cosN*cosN))}`,
       `sin(θ) = ${sinStr},  cos(θ) = ${cosStr}`];

  return {
    type: "cuadrante",
    problem: `${fn}(θ) = ${valStr} en el cuadrante ${qRom}. Halla las 6 razones trigonométricas.`,
    enunciado: `Se sabe que ${fn}(θ) = ${valStr} y que θ se encuentra en el ${qLabel.split("→")[0].trim()}. Determina el valor exacto de las 6 razones trigonométricas.`,
    given: [
      { label: `${fn}(θ)`, value: valStr },
      { label: "Cuadrante", value: qRom },
    ],
    find: ["sin(θ)", "cos(θ)", "tan(θ)", "csc(θ)", "sec(θ)", "cot(θ)"],
    steps: [
      {
        title: "Paso 1 — Identificar signos en el cuadrante",
        lines: [
          `Cuadrante ${qRom}: ${qLabel.split("→")[1].trim()}`,
          `Esta información definirá el signo de cada razón.`,
        ],
      },
      {
        title: `Paso 2 — Hallar ${fn === "sin" ? "cos(θ)" : fn === "cos" ? "sin(θ)" : "sin(θ) y cos(θ)"} con la identidad pitagórica`,
        lines: [
          `Identidad:  sin²(θ) + cos²(θ) = 1`,
          ``,
          ...pythStep,
        ],
        despeje: `sin²(θ) + cos²(θ) = 1`,
      },
      {
        title: "Paso 3 — Calcular tan(θ)",
        lines: [
          `tan(θ) = sin(θ) / cos(θ)`,
          `tan(θ) = (${sinStr}) / (${cosStr})`,
          `tan(θ) = ${tanStr}`,
        ],
        despeje: `tan(θ) = sin(θ) / cos(θ)`,
      },
      {
        title: "Paso 4 — Razones recíprocas",
        lines: [
          `csc(θ) = 1 / sin(θ) = 1 / (${sinStr})`,
          `csc(θ) = ${sinN < 0 ? "−" : ""}${frac(hyp, Math.abs(sinN))}`,
          ``,
          `sec(θ) = 1 / cos(θ) = 1 / (${cosStr})`,
          `sec(θ) = ${cosN < 0 ? "−" : ""}${frac(hyp, Math.abs(cosN))}`,
          ``,
          `cot(θ) = 1 / tan(θ) = (${cosStr}) / (${sinStr})`,
          `cot(θ) = ${tDen === 1 ? `${tDen < 0 ? "−" : ""}${Math.abs(tDen)}` : `${tNum < 0 ? "" : ""}${frac(Math.abs(tDen), Math.abs(tNum))}`}`,
        ],
        despeje: `csc = 1/sin  |  sec = 1/cos  |  cot = cos/sin`,
      },
    ],
    respuesta: [
      { label: "sin(θ)", value: sinStr },
      { label: "cos(θ)", value: cosStr },
      { label: "tan(θ)", value: tanStr },
      { label: "csc(θ)", value: `${sinN < 0 ? "−" : ""}${frac(hyp, Math.abs(sinN))}` },
      { label: "sec(θ)", value: `${cosN < 0 ? "−" : ""}${frac(hyp, Math.abs(cosN))}` },
      { label: "cot(θ)", value: `${frac(Math.abs(tDen), Math.abs(tNum))}` },
    ],
  };
}

// ─── Generator 4: Simplificación algebraica de expresiones ──────────────────

interface SimplExpr {
  expr: string;
  title: string;
  steps: Step[];
  result: string;
}

const SIMPLIFICATIONS: SimplExpr[] = [
  {
    expr: "tan(θ) · cos(θ)",
    title: "Simplifica: tan(θ) · cos(θ)",
    steps: [
      {
        title: "Paso 1 — Escribir tan(θ) en función de sin y cos",
        lines: [
          `tan(θ) = sin(θ) / cos(θ)`,
          ``,
          `Sustituir en la expresión:`,
          `  tan(θ) · cos(θ) = [sin(θ) / cos(θ)] · cos(θ)`,
        ],
        despeje: `tan(θ) = sin(θ) / cos(θ)`,
      },
      {
        title: "Paso 2 — Cancelar cos(θ)",
        lines: [
          `  = sin(θ) · cos(θ) / cos(θ)`,
          `  = sin(θ)          ← cos(θ) se cancela en numerador y denominador`,
        ],
      },
      {
        title: "Paso 3 — Resultado",
        lines: [`tan(θ) · cos(θ) = sin(θ)`],
        despeje: `Resultado: sin(θ)`,
      },
    ],
    result: "sin(θ)",
  },
  {
    expr: "(1 − cos²θ) / sin(θ)",
    title: "Simplifica: (1 − cos²θ) / sin(θ)",
    steps: [
      {
        title: "Paso 1 — Reemplazar (1 − cos²θ) usando la identidad pitagórica",
        lines: [
          `De  sin²(θ) + cos²(θ) = 1  se despeja:`,
          `  1 − cos²(θ) = sin²(θ)`,
        ],
        despeje: `1 − cos²(θ) = sin²(θ)`,
      },
      {
        title: "Paso 2 — Sustituir en la expresión",
        lines: [
          `(1 − cos²θ) / sin(θ) = sin²(θ) / sin(θ)`,
        ],
      },
      {
        title: "Paso 3 — Simplificar la fracción",
        lines: [
          `sin²(θ) / sin(θ) = sin(θ)   ← se cancela un factor sin(θ)`,
        ],
        despeje: `Resultado: sin(θ)`,
      },
    ],
    result: "sin(θ)",
  },
  {
    expr: "sec(θ) / tan(θ)",
    title: "Simplifica: sec(θ) / tan(θ)",
    steps: [
      {
        title: "Paso 1 — Expresar sec y tan en términos de sin y cos",
        lines: [
          `sec(θ) = 1 / cos(θ)`,
          `tan(θ) = sin(θ) / cos(θ)`,
        ],
        despeje: `sec = 1/cos  |  tan = sin/cos`,
      },
      {
        title: "Paso 2 — Sustituir y dividir fracciones",
        lines: [
          `sec(θ) / tan(θ) = [1/cos(θ)] / [sin(θ)/cos(θ)]`,
          ``,
          `Dividir = multiplicar por el recíproco:`,
          `  = [1/cos(θ)] · [cos(θ)/sin(θ)]`,
          `  = cos(θ) / [cos(θ) · sin(θ)]`,
        ],
      },
      {
        title: "Paso 3 — Cancelar cos(θ)",
        lines: [
          `  = 1 / sin(θ)`,
          `  = csc(θ)`,
        ],
        despeje: `Resultado: csc(θ)`,
      },
    ],
    result: "csc(θ)",
  },
  {
    expr: "sin(θ) · cot(θ) + cos(θ) · tan(θ)",
    title: "Simplifica: sin(θ)·cot(θ) + cos(θ)·tan(θ)",
    steps: [
      {
        title: "Paso 1 — Sustituir cot y tan por sus definiciones",
        lines: [
          `cot(θ) = cos(θ) / sin(θ)`,
          `tan(θ) = sin(θ) / cos(θ)`,
        ],
        despeje: `cot = cos/sin  |  tan = sin/cos`,
      },
      {
        title: "Paso 2 — Desarrollar cada término",
        lines: [
          `sin(θ) · cot(θ) = sin(θ) · [cos(θ)/sin(θ)] = cos(θ)`,
          ``,
          `cos(θ) · tan(θ) = cos(θ) · [sin(θ)/cos(θ)] = sin(θ)`,
        ],
      },
      {
        title: "Paso 3 — Sumar los resultados",
        lines: [
          `sin(θ)·cot(θ) + cos(θ)·tan(θ) = cos(θ) + sin(θ)`,
        ],
        despeje: `Resultado: sin(θ) + cos(θ)`,
      },
    ],
    result: "sin(θ) + cos(θ)",
  },
  {
    expr: "(sin²θ + cos²θ) / cos²θ",
    title: "Simplifica: (sin²θ + cos²θ) / cos²θ",
    steps: [
      {
        title: "Paso 1 — Aplicar la identidad pitagórica al numerador",
        lines: [
          `sin²(θ) + cos²(θ) = 1`,
        ],
        despeje: `sin²(θ) + cos²(θ) = 1`,
      },
      {
        title: "Paso 2 — Sustituir en la expresión",
        lines: [
          `(sin²θ + cos²θ) / cos²θ = 1 / cos²(θ)`,
        ],
      },
      {
        title: "Paso 3 — Reconocer como razón conocida",
        lines: [
          `1 / cos²(θ) = sec²(θ)`,
          ``,
          `(Definición: sec(θ) = 1/cos(θ)  →  sec²(θ) = 1/cos²(θ))`,
        ],
        despeje: `Resultado: sec²(θ)`,
      },
    ],
    result: "sec²(θ)",
  },
  {
    expr: "csc(θ) − cot(θ) · cos(θ)",
    title: "Simplifica: csc(θ) − cot(θ) · cos(θ)",
    steps: [
      {
        title: "Paso 1 — Escribir csc y cot en función de sin y cos",
        lines: [
          `csc(θ) = 1 / sin(θ)`,
          `cot(θ) = cos(θ) / sin(θ)`,
        ],
        despeje: `csc = 1/sin  |  cot = cos/sin`,
      },
      {
        title: "Paso 2 — Sustituir en la expresión",
        lines: [
          `csc(θ) − cot(θ)·cos(θ) = 1/sin(θ) − [cos(θ)/sin(θ)]·cos(θ)`,
          `  = 1/sin(θ) − cos²(θ)/sin(θ)`,
        ],
      },
      {
        title: "Paso 3 — Denominator común y simplificar",
        lines: [
          `  = [1 − cos²(θ)] / sin(θ)`,
          ``,
          `Como  1 − cos²(θ) = sin²(θ)  (identidad pitagórica):`,
          `  = sin²(θ) / sin(θ)`,
          `  = sin(θ)`,
        ],
        despeje: `Resultado: sin(θ)`,
      },
    ],
    result: "sin(θ)",
  },
];

function genSimplificacion(): GeneratedExercise {
  const s = randomOf(SIMPLIFICATIONS);
  return {
    type: "simplificacion",
    problem: s.title,
    enunciado: `Simplifica la siguiente expresión trigonométrica hasta su forma más reducida. Muestra cada paso algebraico.`,
    given: [{ label: "Expresión", value: s.expr }],
    find: ["Forma simplificada"],
    steps: s.steps,
    respuesta: [{ label: "Resultado", value: s.result }],
  };
}

// ─── Catalogue ───────────────────────────────────────────────────────────────

const EXERCISE_TYPES: { value: ExerciseType; label: string; desc: string }[] = [
  { value: "contextual",    label: "Problema de la vida real",  desc: "Escaleras, edificios, aviones, sombras — situaciones reales con trig" },
  { value: "doble-angulo",  label: "Fórmulas de ángulo doble",  desc: "Dado sin o cos como fracción, calcula sin(2θ), cos(2θ), tan(2θ)" },
  { value: "cuadrante",     label: "Cuadrante y signo",         desc: "Dada una razón y el cuadrante, halla las 6 razones con signos correctos" },
  { value: "simplificacion","label": "Simplificación algebraica","desc": "Reduce una expresión trig a su forma más simple usando identidades" },
];

function generateExercise(type: ExerciseType): GeneratedExercise {
  switch (type) {
    case "contextual":    return genContextual();
    case "doble-angulo":  return genDobleAngulo();
    case "cuadrante":     return genCuadrante();
    case "simplificacion":return genSimplificacion();
  }
}

// ─── Step card ───────────────────────────────────────────────────────────────

function StepCard({ step, index, visible }: { step: Step; index: number; visible: boolean }) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="border-primary/20 bg-card/60">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <span className="flex-shrink-0 flex items-center justify-center bg-primary text-primary-foreground rounded-full w-7 h-7 text-xs font-black">
                  {index + 1}
                </span>
                <CardTitle className="text-sm font-semibold text-foreground">{step.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              {step.despeje && (
                <div className="flex items-start gap-2 bg-primary/10 border border-primary/25 rounded-lg px-3 py-2">
                  <ChevronRight className="w-3.5 h-3.5 text-primary mt-0.5 flex-shrink-0" />
                  <span className="font-mono text-sm text-primary font-semibold">{step.despeje}</span>
                </div>
              )}
              <div className="space-y-0.5">
                {step.lines.map((line, i) =>
                  line === "" ? (
                    <div key={i} className="h-2" />
                  ) : (
                    <div key={i} className="font-mono text-sm text-foreground/85 leading-relaxed whitespace-pre-wrap">
                      {line}
                    </div>
                  )
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Page ────────────────────────────────────────────────────────────────────

export default function Ejercicios() {
  const [exerciseType, setExerciseType] = useState<ExerciseType>("contextual");
  const [exercise, setExercise] = useState<GeneratedExercise | null>(null);
  const [showSolution, setShowSolution] = useState(false);
  const [visibleSteps, setVisibleSteps] = useState(0);

  const handleGenerate = () => {
    setExercise(generateExercise(exerciseType));
    setShowSolution(false);
    setVisibleSteps(0);
  };

  const handleReveal = () => {
    if (!exercise) return;
    setShowSolution(true);
    let i = 0;
    const next = () => {
      i++;
      setVisibleSteps(i);
      if (i < exercise.steps.length) setTimeout(next, 420);
    };
    setTimeout(next, 80);
  };

  const currentType = EXERCISE_TYPES.find((t) => t.value === exerciseType)!;

  return (
    <Layout>
      <div className="space-y-8 max-w-3xl">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Ejercicios</h1>
          <p className="text-muted-foreground mt-2">Genera problemas variados y visualiza el desarrollo completo con despejes algebraicos.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Tipo de ejercicio</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-2">
              <Label>Categoría</Label>
              <Select value={exerciseType} onValueChange={(v) => setExerciseType(v as ExerciseType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EXERCISE_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">{currentType.desc}</p>
            </div>

            <Button onClick={handleGenerate} className="w-full gap-2" size="lg">
              <RefreshCw className="w-4 h-4" />
              Generar ejercicio
            </Button>
          </CardContent>
        </Card>

        <AnimatePresence mode="wait">
          {exercise && (
            <motion.div
              key={exercise.problem}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="space-y-5"
            >
              <Card className="border-primary/30 bg-gradient-to-br from-card to-primary/5">
                <CardHeader className="pb-3">
                  <div className="text-xs font-semibold uppercase tracking-widest text-primary mb-1">Enunciado</div>
                  <div className="font-bold text-lg text-foreground leading-snug">{exercise.problem}</div>
                </CardHeader>
                <CardContent className="space-y-4 pt-0">
                  <p className="text-muted-foreground text-sm">{exercise.enunciado}</p>

                  {exercise.contexto && (
                    <div className="bg-primary/5 border border-primary/15 rounded-lg px-3 py-2 text-xs text-muted-foreground italic">
                      {exercise.contexto}
                    </div>
                  )}

                  <div className="flex flex-wrap gap-4">
                    <div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mb-2 font-semibold">Datos</div>
                      <div className="flex flex-wrap gap-2">
                        {exercise.given.map((g) => (
                          <div key={g.label} className="font-mono text-sm bg-card/80 border border-border/50 rounded-md px-3 py-1.5 inline-flex items-center gap-2">
                            <span className="text-muted-foreground">{g.label} =</span>
                            <span className="font-bold text-primary">{g.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mb-2 font-semibold">Hallar</div>
                      <div className="flex flex-wrap gap-1">
                        {exercise.find.map((f) => (
                          <span key={f} className="font-mono text-xs bg-primary/10 text-primary border border-primary/20 rounded-full px-2.5 py-1">{f}</span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {!showSolution && (
                    <Button onClick={handleReveal} variant="outline" className="w-full gap-2 border-primary/30 hover:bg-primary/10">
                      <Eye className="w-4 h-4" />
                      Mostrar solución paso a paso
                    </Button>
                  )}
                </CardContent>
              </Card>

              {showSolution && (
                <div className="space-y-3">
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Desarrollo</div>
                  {exercise.steps.map((step, i) => (
                    <StepCard key={i} step={step} index={i} visible={visibleSteps > i} />
                  ))}

                  <AnimatePresence>
                    {visibleSteps >= exercise.steps.length && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.97 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.1 }}
                      >
                        <Card className="border-2 border-primary bg-primary/10">
                          <CardContent className="p-5">
                            <div className="flex items-center gap-3 mb-3">
                              <CheckCircle className="w-6 h-6 text-primary flex-shrink-0" />
                              <span className="font-bold text-lg">Respuesta final</span>
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                              {exercise.respuesta.map((r) => (
                                <div key={r.label} className="bg-card/80 border border-primary/20 rounded-lg px-3 py-2.5 text-center">
                                  <div className="text-xs text-muted-foreground font-mono mb-1">{r.label}</div>
                                  <div className="font-mono font-bold text-primary text-base">{r.value}</div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Layout>
  );
}
