import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toRadians, toDegrees, formatNumber, getExactValue } from "@/lib/math-utils";
import { CheckCircle, XCircle, Variable } from "lucide-react";

interface SideEval {
  label: string;
  steps: string[];
  value: number;
  formatted: string;
}

interface IdentityEval {
  formula: string;
  lhs: SideEval;
  rhs: SideEval;
  match: boolean;
}

interface SymbolicResult {
  formula: string;
  lhsExpr: string;
  rhsExpr: string;
  lhsDesc: string;
  rhsDesc: string;
  variable: string;
}

function isSymbolic(val: string): boolean {
  return val.trim() !== "" && isNaN(parseFloat(val.trim()));
}

function symbolicBothSides(identity: string, v: string): SymbolicResult {
  switch (identity) {
    case "pythagorean-1":
      return { formula: `sin²(${v}) + cos²(${v}) = 1`, lhsExpr: `sin²(${v}) + cos²(${v})`, rhsExpr: "1", lhsDesc: "Suma del cuadrado del seno y el coseno", rhsDesc: "Constante universal", variable: v };
    case "pythagorean-2":
      return { formula: `1 + tan²(${v}) = sec²(${v})`, lhsExpr: `1 + tan²(${v})`, rhsExpr: `sec²(${v})`, lhsDesc: "Uno más el cuadrado de la tangente", rhsDesc: "Cuadrado de la secante", variable: v };
    case "pythagorean-3":
      return { formula: `1 + cot²(${v}) = csc²(${v})`, lhsExpr: `1 + cot²(${v})`, rhsExpr: `csc²(${v})`, lhsDesc: "Uno más el cuadrado de la cotangente", rhsDesc: "Cuadrado de la cosecante", variable: v };
    case "double-sin":
      return { formula: `sin(2${v}) = 2·sin(${v})·cos(${v})`, lhsExpr: `sin(2${v})`, rhsExpr: `2·sin(${v})·cos(${v})`, lhsDesc: "Seno del doble de la incógnita", rhsDesc: "Producto de seno y coseno por 2", variable: v };
    case "double-cos-1":
      return { formula: `cos(2${v}) = cos²(${v}) − sin²(${v})`, lhsExpr: `cos(2${v})`, rhsExpr: `cos²(${v}) − sin²(${v})`, lhsDesc: "Coseno del doble de la incógnita", rhsDesc: "Diferencia de cuadrados", variable: v };
    case "double-cos-2":
      return { formula: `cos(2${v}) = 2cos²(${v}) − 1`, lhsExpr: `cos(2${v})`, rhsExpr: `2cos²(${v}) − 1`, lhsDesc: "Coseno del doble de la incógnita", rhsDesc: "Forma en función del coseno", variable: v };
    case "double-cos-3":
      return { formula: `cos(2${v}) = 1 − 2sin²(${v})`, lhsExpr: `cos(2${v})`, rhsExpr: `1 − 2sin²(${v})`, lhsDesc: "Coseno del doble de la incógnita", rhsDesc: "Forma en función del seno", variable: v };
    case "double-tan":
      return { formula: `tan(2${v}) = 2tan(${v}) / (1 − tan²(${v}))`, lhsExpr: `tan(2${v})`, rhsExpr: `2tan(${v}) / (1 − tan²(${v}))`, lhsDesc: "Tangente del doble de la incógnita", rhsDesc: "Cociente en función de la tangente", variable: v };
    case "recip-csc":
      return { formula: `csc(${v}) = 1 / sin(${v})`, lhsExpr: `csc(${v})`, rhsExpr: `1 / sin(${v})`, lhsDesc: "Cosecante de la incógnita", rhsDesc: "Recíproco del seno", variable: v };
    case "recip-sec":
      return { formula: `sec(${v}) = 1 / cos(${v})`, lhsExpr: `sec(${v})`, rhsExpr: `1 / cos(${v})`, lhsDesc: "Secante de la incógnita", rhsDesc: "Recíproco del coseno", variable: v };
    case "recip-cot":
      return { formula: `cot(${v}) = 1 / tan(${v})`, lhsExpr: `cot(${v})`, rhsExpr: `1 / tan(${v})`, lhsDesc: "Cotangente de la incógnita", rhsDesc: "Recíproco de la tangente", variable: v };
    case "quot-tan":
      return { formula: `tan(${v}) = sin(${v}) / cos(${v})`, lhsExpr: `tan(${v})`, rhsExpr: `sin(${v}) / cos(${v})`, lhsDesc: "Tangente de la incógnita", rhsDesc: "Cociente seno sobre coseno", variable: v };
    case "quot-cot":
      return { formula: `cot(${v}) = cos(${v}) / sin(${v})`, lhsExpr: `cot(${v})`, rhsExpr: `cos(${v}) / sin(${v})`, lhsDesc: "Cotangente de la incógnita", rhsDesc: "Cociente coseno sobre seno", variable: v };
    default:
      return { formula: "", lhsExpr: "", rhsExpr: "", lhsDesc: "", rhsDesc: "", variable: v };
  }
}

const IDENTITIES = [
  { value: "pythagorean-1", label: "Pitagórica: sin²(θ) + cos²(θ) = 1" },
  { value: "pythagorean-2", label: "Pitagórica: 1 + tan²(θ) = sec²(θ)" },
  { value: "pythagorean-3", label: "Pitagórica: 1 + cot²(θ) = csc²(θ)" },
  { value: "double-sin",    label: "Doble ángulo: sin(2θ) = 2sin(θ)cos(θ)" },
  { value: "double-cos-1",  label: "Doble ángulo: cos(2θ) = cos²(θ) − sin²(θ)" },
  { value: "double-cos-2",  label: "Doble ángulo: cos(2θ) = 2cos²(θ) − 1" },
  { value: "double-cos-3",  label: "Doble ángulo: cos(2θ) = 1 − 2sin²(θ)" },
  { value: "double-tan",    label: "Doble ángulo: tan(2θ) = 2tan(θ)/(1−tan²(θ))" },
  { value: "recip-csc",     label: "Recíproca: csc(θ) = 1/sin(θ)" },
  { value: "recip-sec",     label: "Recíproca: sec(θ) = 1/cos(θ)" },
  { value: "recip-cot",     label: "Recíproca: cot(θ) = 1/tan(θ)" },
  { value: "quot-tan",      label: "Cociente: tan(θ) = sin(θ)/cos(θ)" },
  { value: "quot-cot",      label: "Cociente: cot(θ) = cos(θ)/sin(θ)" },
];

function fmt(n: number): string {
  if (!isFinite(n)) return "Indefinido";
  if (Math.abs(n) < 1e-10) return "0";
  return formatNumber(n);
}

function evalBothSides(identity: string, rad: number, deg: number, unit: string, numAngle: number): IdentityEval {
  const sin = Math.sin(rad);
  const cos = Math.cos(rad);
  const tan = Math.tan(rad);
  const csc = 1 / sin;
  const sec = 1 / cos;
  const cot = cos / sin;
  const exact = getExactValue(((deg % 360) + 360) % 360);
  const sinExact = exact ? exact.sin : fmt(sin);
  const cosExact = exact ? exact.cos : fmt(cos);
  const tanExact = exact ? exact.tan : fmt(tan);
  const angleStr = `${numAngle}${unit === "deg" ? "°" : " rad"}`;

  switch (identity) {
    case "pythagorean-1": {
      const lhsVal = sin * sin + cos * cos;
      return {
        formula: "sin²(θ) + cos²(θ) = 1",
        lhs: {
          label: "sin²(θ) + cos²(θ)",
          steps: [
            `Sustituir θ = ${angleStr}`,
            `sin(${angleStr}) = ${sinExact}  →  sin²(θ) = ${fmt(sin * sin)}`,
            `cos(${angleStr}) = ${cosExact}  →  cos²(θ) = ${fmt(cos * cos)}`,
            `Sumar: ${fmt(sin * sin)} + ${fmt(cos * cos)} = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "1",
          steps: ["La identidad pitagórica establece que el lado derecho es la constante 1."],
          value: 1,
          formatted: "1",
        },
        match: Math.abs(lhsVal - 1) < 1e-8,
      };
    }

    case "pythagorean-2": {
      const lhsVal = 1 + tan * tan;
      const rhsVal = sec * sec;
      return {
        formula: "1 + tan²(θ) = sec²(θ)",
        lhs: {
          label: "1 + tan²(θ)",
          steps: [
            `Sustituir θ = ${angleStr}`,
            `tan(${angleStr}) = ${tanExact}  →  tan²(θ) = ${fmt(tan * tan)}`,
            `Sumar: 1 + ${fmt(tan * tan)} = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "sec²(θ)",
          steps: [
            `sec(θ) = 1/cos(θ)`,
            `cos(${angleStr}) = ${cosExact}  →  sec(θ) = 1/${cosExact} = ${fmt(sec)}`,
            `sec²(θ) = ${fmt(sec)}² = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-6,
      };
    }

    case "pythagorean-3": {
      const lhsVal = 1 + cot * cot;
      const rhsVal = csc * csc;
      return {
        formula: "1 + cot²(θ) = csc²(θ)",
        lhs: {
          label: "1 + cot²(θ)",
          steps: [
            `Sustituir θ = ${angleStr}`,
            `cot(θ) = cos(θ)/sin(θ) = ${cosExact}/${sinExact} = ${fmt(cot)}`,
            `cot²(θ) = ${fmt(cot * cot)}`,
            `1 + ${fmt(cot * cot)} = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "csc²(θ)",
          steps: [
            `csc(θ) = 1/sin(θ)`,
            `sin(${angleStr}) = ${sinExact}  →  csc(θ) = ${fmt(csc)}`,
            `csc²(θ) = ${fmt(csc)}² = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-6,
      };
    }

    case "double-sin": {
      const lhsVal = Math.sin(2 * rad);
      const rhsVal = 2 * sin * cos;
      const twoAngle = numAngle * 2;
      return {
        formula: "sin(2θ) = 2·sin(θ)·cos(θ)",
        lhs: {
          label: "sin(2θ)",
          steps: [
            `Calcular el doble del ángulo: 2θ = 2 × ${angleStr} = ${twoAngle}${unit === "deg" ? "°" : " rad"}`,
            `sin(${twoAngle}${unit === "deg" ? "°" : " rad"}) = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "2·sin(θ)·cos(θ)",
          steps: [
            `sin(${angleStr}) = ${sinExact} = ${fmt(sin)}`,
            `cos(${angleStr}) = ${cosExact} = ${fmt(cos)}`,
            `2 × ${fmt(sin)} × ${fmt(cos)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    case "double-cos-1": {
      const lhsVal = Math.cos(2 * rad);
      const rhsVal = cos * cos - sin * sin;
      const twoAngle = numAngle * 2;
      return {
        formula: "cos(2θ) = cos²(θ) − sin²(θ)",
        lhs: {
          label: "cos(2θ)",
          steps: [
            `2θ = ${twoAngle}${unit === "deg" ? "°" : " rad"}`,
            `cos(${twoAngle}${unit === "deg" ? "°" : " rad"}) = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "cos²(θ) − sin²(θ)",
          steps: [
            `cos(${angleStr}) = ${cosExact}  →  cos²(θ) = ${fmt(cos * cos)}`,
            `sin(${angleStr}) = ${sinExact}  →  sin²(θ) = ${fmt(sin * sin)}`,
            `${fmt(cos * cos)} − ${fmt(sin * sin)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    case "double-cos-2": {
      const lhsVal = Math.cos(2 * rad);
      const rhsVal = 2 * cos * cos - 1;
      const twoAngle = numAngle * 2;
      return {
        formula: "cos(2θ) = 2cos²(θ) − 1",
        lhs: {
          label: "cos(2θ)",
          steps: [
            `2θ = ${twoAngle}${unit === "deg" ? "°" : " rad"}`,
            `cos(${twoAngle}${unit === "deg" ? "°" : " rad"}) = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "2cos²(θ) − 1",
          steps: [
            `cos(${angleStr}) = ${cosExact}  →  cos²(θ) = ${fmt(cos * cos)}`,
            `2 × ${fmt(cos * cos)} − 1 = ${fmt(2 * cos * cos)} − 1 = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    case "double-cos-3": {
      const lhsVal = Math.cos(2 * rad);
      const rhsVal = 1 - 2 * sin * sin;
      const twoAngle = numAngle * 2;
      return {
        formula: "cos(2θ) = 1 − 2sin²(θ)",
        lhs: {
          label: "cos(2θ)",
          steps: [
            `2θ = ${twoAngle}${unit === "deg" ? "°" : " rad"}`,
            `cos(${twoAngle}${unit === "deg" ? "°" : " rad"}) = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "1 − 2sin²(θ)",
          steps: [
            `sin(${angleStr}) = ${sinExact}  →  sin²(θ) = ${fmt(sin * sin)}`,
            `1 − 2 × ${fmt(sin * sin)} = 1 − ${fmt(2 * sin * sin)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    case "double-tan": {
      const lhsVal = Math.tan(2 * rad);
      const rhsVal = (2 * tan) / (1 - tan * tan);
      const twoAngle = numAngle * 2;
      return {
        formula: "tan(2θ) = 2tan(θ) / (1 − tan²(θ))",
        lhs: {
          label: "tan(2θ)",
          steps: [
            `2θ = ${twoAngle}${unit === "deg" ? "°" : " rad"}`,
            `tan(${twoAngle}${unit === "deg" ? "°" : " rad"}) = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "2tan(θ) / (1 − tan²(θ))",
          steps: [
            `tan(${angleStr}) = ${tanExact} = ${fmt(tan)}`,
            `Numerador: 2 × ${fmt(tan)} = ${fmt(2 * tan)}`,
            `Denominador: 1 − ${fmt(tan)}² = 1 − ${fmt(tan * tan)} = ${fmt(1 - tan * tan)}`,
            `Resultado: ${fmt(2 * tan)} / ${fmt(1 - tan * tan)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-6,
      };
    }

    case "recip-csc": {
      const lhsVal = csc;
      const rhsVal = 1 / sin;
      return {
        formula: "csc(θ) = 1/sin(θ)",
        lhs: {
          label: "csc(θ)",
          steps: [
            `csc(θ) se define como el recíproco del seno`,
            `csc(${angleStr}) = ${fmt(lhsVal)}`,
          ],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "1/sin(θ)",
          steps: [
            `sin(${angleStr}) = ${sinExact} = ${fmt(sin)}`,
            `1 / ${fmt(sin)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    case "recip-sec": {
      const lhsVal = sec;
      const rhsVal = 1 / cos;
      return {
        formula: "sec(θ) = 1/cos(θ)",
        lhs: {
          label: "sec(θ)",
          steps: [`sec(${angleStr}) = ${fmt(lhsVal)}`],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "1/cos(θ)",
          steps: [
            `cos(${angleStr}) = ${cosExact} = ${fmt(cos)}`,
            `1 / ${fmt(cos)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    case "recip-cot": {
      const lhsVal = cot;
      const rhsVal = 1 / tan;
      return {
        formula: "cot(θ) = 1/tan(θ)",
        lhs: {
          label: "cot(θ)",
          steps: [`cot(${angleStr}) = ${fmt(lhsVal)}`],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "1/tan(θ)",
          steps: [
            `tan(${angleStr}) = ${tanExact} = ${fmt(tan)}`,
            `1 / ${fmt(tan)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    case "quot-tan": {
      const lhsVal = tan;
      const rhsVal = sin / cos;
      return {
        formula: "tan(θ) = sin(θ)/cos(θ)",
        lhs: {
          label: "tan(θ)",
          steps: [`tan(${angleStr}) = ${tanExact} = ${fmt(lhsVal)}`],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "sin(θ)/cos(θ)",
          steps: [
            `sin(${angleStr}) = ${sinExact} = ${fmt(sin)}`,
            `cos(${angleStr}) = ${cosExact} = ${fmt(cos)}`,
            `${fmt(sin)} / ${fmt(cos)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    case "quot-cot": {
      const lhsVal = cot;
      const rhsVal = cos / sin;
      return {
        formula: "cot(θ) = cos(θ)/sin(θ)",
        lhs: {
          label: "cot(θ)",
          steps: [`cot(${angleStr}) = ${fmt(lhsVal)}`],
          value: lhsVal,
          formatted: fmt(lhsVal),
        },
        rhs: {
          label: "cos(θ)/sin(θ)",
          steps: [
            `cos(${angleStr}) = ${cosExact} = ${fmt(cos)}`,
            `sin(${angleStr}) = ${sinExact} = ${fmt(sin)}`,
            `${fmt(cos)} / ${fmt(sin)} = ${fmt(rhsVal)}`,
          ],
          value: rhsVal,
          formatted: fmt(rhsVal),
        },
        match: Math.abs(lhsVal - rhsVal) < 1e-8,
      };
    }

    default:
      return {
        formula: "",
        lhs: { label: "", steps: [], value: 0, formatted: "0" },
        rhs: { label: "", steps: [], value: 0, formatted: "0" },
        match: false,
      };
  }
}

function SideCard({ title, side, delay }: { title: string; side: SideEval; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="flex-1"
    >
      <Card className="h-full border-primary/20 bg-card/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">{title}</CardTitle>
          <div className="font-mono text-xl text-primary font-bold">{side.label}</div>
        </CardHeader>
        <CardContent className="space-y-2">
          {side.steps.map((s, i) => (
            <div key={i} className="flex gap-2 items-start text-sm">
              <span className="flex-shrink-0 flex items-center justify-center bg-primary/20 text-primary rounded-full w-5 h-5 text-xs font-bold mt-0.5">
                {i + 1}
              </span>
              <span className="font-mono text-foreground/80">{s}</span>
            </div>
          ))}
          <div className="mt-4 border-t border-border/50 pt-3">
            <span className="text-xs text-muted-foreground">Resultado:</span>
            <div className="font-mono text-2xl font-bold text-primary mt-1">{side.formatted}</div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function SymbolicSideCard({ title, expr, desc, delay }: { title: string; expr: string; desc: string; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="flex-1"
    >
      <Card className="h-full border-primary/20 bg-card/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">{title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="font-mono text-2xl font-bold text-primary bg-primary/10 rounded-lg px-4 py-3 text-center border border-primary/20">
            {expr}
          </div>
          <p className="text-sm text-muted-foreground">{desc}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
}

const identitiesRef = {
  pitagoricas: [
    "sin²(θ) + cos²(θ) = 1",
    "1 + tan²(θ) = sec²(θ)",
    "1 + cot²(θ) = csc²(θ)",
  ],
  reciprocas: [
    "csc(θ) = 1 / sin(θ)",
    "sec(θ) = 1 / cos(θ)",
    "cot(θ) = 1 / tan(θ)",
  ],
  cociente: [
    "tan(θ) = sin(θ) / cos(θ)",
    "cot(θ) = cos(θ) / sin(θ)",
  ],
  doble: [
    "sin(2θ) = 2 sin(θ) cos(θ)",
    "cos(2θ) = cos²(θ) − sin²(θ)",
    "cos(2θ) = 2cos²(θ) − 1",
    "cos(2θ) = 1 − 2sin²(θ)",
    "tan(2θ) = 2tan(θ) / (1 − tan²(θ))",
  ],
};

export default function Identidades() {
  const [situation, setSituation] = useState("");
  const [angle, setAngle] = useState("45");
  const [unit, setUnit] = useState<"deg" | "rad">("deg");
  const [identity, setIdentity] = useState("pythagorean-1");
  const [evaluation, setEvaluation] = useState<IdentityEval | null>(null);
  const [symbolic, setSymbolic] = useState<SymbolicResult | null>(null);

  const handleEvaluate = () => {
    const val = angle.trim();
    if (val === "") return;

    if (isSymbolic(val)) {
      setEvaluation(null);
      setSymbolic(symbolicBothSides(identity, val));
      return;
    }

    const numAngle = parseFloat(val);
    if (isNaN(numAngle)) return;
    setSymbolic(null);
    const rad = unit === "deg" ? toRadians(numAngle) : numAngle;
    const deg = unit === "deg" ? numAngle : toDegrees(numAngle);
    setEvaluation(evalBothSides(identity, rad, deg, unit, numAngle));
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Identidades Trigonométricas</h1>
          <p className="text-muted-foreground mt-2">Verifica que ambos lados de una identidad dan el mismo resultado.</p>
        </div>

        <Tabs defaultValue="evaluator" className="w-full">
          <TabsList className="grid grid-cols-2 w-full mb-8">
            <TabsTrigger value="evaluator">Verificador Paso a Paso</TabsTrigger>
            <TabsTrigger value="reference">Referencia</TabsTrigger>
          </TabsList>

          <TabsContent value="evaluator">
            <Card>
              <CardHeader>
                <CardTitle>Evaluación de Ambos Lados</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Descripción del problema (opcional)</Label>
                  <Textarea
                    value={situation}
                    onChange={(e) => setSituation(e.target.value)}
                    placeholder="Ej: Verifica que sin²(45°) + cos²(45°) = 1 usando la identidad pitagórica"
                    rows={2}
                  />
                </div>
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="space-y-2 flex-1">
                    <Label>Identidad a verificar</Label>
                    <Select value={identity} onValueChange={setIdentity}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {IDENTITIES.map((id) => (
                          <SelectItem key={id.value} value={id.value}>{id.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2 w-36">
                    <Label className="flex items-center gap-1">
                      Ángulo / Incógnita
                      <Variable className="w-3 h-3 text-muted-foreground" />
                    </Label>
                    <Input
                      type="text"
                      value={angle}
                      onChange={(e) => setAngle(e.target.value)}
                      placeholder="45  o  x  o  α"
                      className="font-mono"
                    />
                    <p className="text-xs text-muted-foreground leading-tight">
                      Número → evalúa.<br />Letra → forma simbólica.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Unidad <span className="text-muted-foreground text-xs">(solo numérico)</span></Label>
                    <Tabs value={unit} onValueChange={(v) => setUnit(v as "deg" | "rad")}>
                      <TabsList>
                        <TabsTrigger value="deg">Grados</TabsTrigger>
                        <TabsTrigger value="rad">Radianes</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>
                </div>
                <Button
                  data-testid="button-evaluate"
                  onClick={handleEvaluate}
                  className="w-full"
                  size="lg"
                >
                  Verificar Identidad
                </Button>
              </CardContent>
            </Card>

            <AnimatePresence>
              {symbolic && (
                <motion.div
                  key={"sym-" + symbolic.formula}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6 mt-6"
                >
                  {situation && (
                    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                      <Card className="border-primary/30 bg-primary/5">
                        <CardContent className="p-4 text-sm text-muted-foreground italic">{situation}</CardContent>
                      </Card>
                    </motion.div>
                  )}

                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="text-center"
                  >
                    <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-1.5 mb-3">
                      <Variable className="w-3.5 h-3.5 text-primary" />
                      <span className="text-xs text-primary font-medium">Modo simbólico — incógnita: <strong>{symbolic.variable}</strong></span>
                    </div>
                    <div className="font-mono text-2xl font-bold text-foreground bg-card border border-primary/20 rounded-xl px-6 py-4">
                      {symbolic.formula}
                    </div>
                  </motion.div>

                  <div className="flex flex-col md:flex-row gap-4 items-stretch">
                    <SymbolicSideCard title="Lado Izquierdo (L.I.)" expr={symbolic.lhsExpr} desc={symbolic.lhsDesc} delay={0.2} />
                    <motion.div
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.35 }}
                      className="flex items-center justify-center text-3xl font-bold text-muted-foreground self-center"
                    >
                      =
                    </motion.div>
                    <SymbolicSideCard title="Lado Derecho (L.D.)" expr={symbolic.rhsExpr} desc={symbolic.rhsDesc} delay={0.4} />
                  </div>

                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 }}
                  >
                    <Card className="border-2 border-primary bg-primary/10">
                      <CardContent className="p-5 flex items-center gap-4">
                        <CheckCircle className="w-8 h-8 text-primary flex-shrink-0" />
                        <div>
                          <div className="font-bold text-lg">Identidad válida para todo valor de <span className="text-primary font-mono">{symbolic.variable}</span></div>
                          <div className="font-mono text-sm text-muted-foreground mt-1">
                            {symbolic.lhsExpr} = {symbolic.rhsExpr}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {evaluation && (
                <motion.div
                  key={evaluation.formula}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6 mt-6"
                >
                  {situation && (
                    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                      <Card className="border-primary/30 bg-primary/5">
                        <CardContent className="p-4 text-sm text-muted-foreground italic">
                          {situation}
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}

                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="text-center"
                  >
                    <span className="font-mono text-xl font-bold text-foreground bg-card border border-primary/20 rounded-xl px-6 py-3 inline-block">
                      {evaluation.formula}
                    </span>
                  </motion.div>

                  <div className="flex flex-col md:flex-row gap-4 items-stretch">
                    <SideCard title="Lado Izquierdo (L.I.)" side={evaluation.lhs} delay={0.2} />

                    <motion.div
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.35 }}
                      className="flex items-center justify-center text-3xl font-bold text-muted-foreground self-center"
                    >
                      =
                    </motion.div>

                    <SideCard title="Lado Derecho (L.D.)" side={evaluation.rhs} delay={0.4} />
                  </div>

                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 }}
                  >
                    <Card className={`border-2 ${evaluation.match ? "border-primary bg-primary/10" : "border-destructive bg-destructive/10"}`}>
                      <CardContent className="p-5 flex items-center gap-4">
                        {evaluation.match
                          ? <CheckCircle className="w-8 h-8 text-primary flex-shrink-0" />
                          : <XCircle className="w-8 h-8 text-destructive flex-shrink-0" />
                        }
                        <div>
                          <div className="font-bold text-lg">
                            {evaluation.match ? "Identidad verificada" : "Los valores no coinciden"}
                          </div>
                          <div className="font-mono text-sm text-muted-foreground mt-1">
                            L.I. = {evaluation.lhs.formatted}
                            {"  =  "}
                            L.D. = {evaluation.rhs.formatted}
                            {evaluation.match ? "  ✓" : "  ✗"}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </TabsContent>

          <TabsContent value="reference">
            <Tabs defaultValue="pitagoricas" className="w-full">
              <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full mb-8">
                <TabsTrigger value="pitagoricas">Pitagóricas</TabsTrigger>
                <TabsTrigger value="reciprocas">Recíprocas</TabsTrigger>
                <TabsTrigger value="cociente">Cociente</TabsTrigger>
                <TabsTrigger value="doble">Doble Ángulo</TabsTrigger>
              </TabsList>
              {Object.entries(identitiesRef).map(([key, list]) => (
                <TabsContent key={key} value={key}>
                  <div className="grid gap-4 md:grid-cols-2">
                    {list.map((ident, i) => (
                      <Card key={i} className="bg-card/50 border-primary/20">
                        <CardContent className="p-6 flex items-center justify-center">
                          <code className="text-lg text-primary font-mono bg-primary/10 px-4 py-2 rounded-md text-center">
                            {ident}
                          </code>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
