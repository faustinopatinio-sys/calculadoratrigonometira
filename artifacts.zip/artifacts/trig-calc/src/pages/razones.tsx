import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toRadians, toDegrees, formatNumber, getExactValue } from "@/lib/math-utils";

export default function Razones() {
  const [angle, setAngle] = useState("45");
  const [unit, setUnit] = useState<"deg" | "rad">("deg");
  const [situation, setSituation] = useState("");
  const [results, setResults] = useState<any>(null);

  const calculate = () => {
    const numAngle = parseFloat(angle);
    if (isNaN(numAngle)) return;

    let deg = unit === "deg" ? numAngle : toDegrees(numAngle);
    let rad = unit === "rad" ? numAngle : toRadians(numAngle);

    // Normalize degrees to 0-360 for exact values lookup
    const normalizedDeg = ((deg % 360) + 360) % 360;
    
    // Determine quadrant
    let quadrant = 1;
    if (normalizedDeg > 90 && normalizedDeg <= 180) quadrant = 2;
    else if (normalizedDeg > 180 && normalizedDeg <= 270) quadrant = 3;
    else if (normalizedDeg > 270 && normalizedDeg < 360) quadrant = 4;
    else if (normalizedDeg === 0 || normalizedDeg === 90 || normalizedDeg === 180 || normalizedDeg === 270) quadrant = 0; // Quadrantal

    const refAngle = quadrant === 1 ? normalizedDeg :
                    quadrant === 2 ? 180 - normalizedDeg :
                    quadrant === 3 ? normalizedDeg - 180 :
                    360 - normalizedDeg;

    const exact = getExactValue(normalizedDeg);

    const sinVal = Math.sin(rad);
    const cosVal = Math.cos(rad);
    const tanVal = Math.tan(rad);
    
    const steps = [
      {
        id: 1,
        title: "Paso 1: Convertir y Normalizar",
        content: `Ángulo dado: ${angle}${unit === "deg" ? "°" : " rad"}. \nEn grados normalizados (0-360°): ${formatNumber(normalizedDeg)}°\n${situation ? `Situación: ${situation}` : ''}`
      },
      {
        id: 2,
        title: "Paso 2: Identificar Cuadrante",
        content: quadrant === 0 ? 
                 `El ángulo cae sobre un eje coordenado (ángulo cuadrantal).` :
                 `El ángulo está en el Cuadrante ${quadrant}. Ángulo de referencia: ${formatNumber(refAngle)}°`
      },
      {
        id: 3,
        title: "Paso 3: Calcular Razones Básicas",
        content: (
          <div className="space-y-2 font-mono text-sm mt-2">
            <div className="flex justify-between border-b border-border/50 pb-1">
              <span>sin(θ)</span>
              <span>{exact ? exact.sin : formatNumber(sinVal)}</span>
            </div>
            <div className="flex justify-between border-b border-border/50 pb-1">
              <span>cos(θ)</span>
              <span>{exact ? exact.cos : formatNumber(cosVal)}</span>
            </div>
            <div className="flex justify-between border-b border-border/50 pb-1">
              <span>tan(θ)</span>
              <span>{exact ? exact.tan : formatNumber(tanVal)}</span>
            </div>
          </div>
        )
      },
      {
        id: 4,
        title: "Paso 4: Calcular Razones Recíprocas",
        content: (
          <div className="space-y-2 font-mono text-sm mt-2">
            <div className="flex justify-between border-b border-border/50 pb-1">
              <span>csc(θ) = 1/sin(θ)</span>
              <span>{Math.abs(sinVal) < 1e-10 ? "Indefinido" : formatNumber(1/sinVal)}</span>
            </div>
            <div className="flex justify-between border-b border-border/50 pb-1">
              <span>sec(θ) = 1/cos(θ)</span>
              <span>{Math.abs(cosVal) < 1e-10 ? "Indefinido" : formatNumber(1/cosVal)}</span>
            </div>
            <div className="flex justify-between border-b border-border/50 pb-1">
              <span>cot(θ) = 1/tan(θ)</span>
              <span>{Math.abs(tanVal) < 1e-10 ? "Indefinido" : formatNumber(1/tanVal)}</span>
            </div>
          </div>
        )
      }
    ];

    setResults(steps);
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Razones Trigonométricas</h1>
          <p className="text-muted-foreground mt-2">Calcula las seis razones trigonométricas para cualquier ángulo.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Entrada de Ángulo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="situation">Descripción del problema (opcional)</Label>
              <Textarea 
                id="situation"
                value={situation}
                onChange={(e) => setSituation(e.target.value)}
                placeholder="Ej: En un triángulo rectángulo, el lado opuesto mide 3 y la hipotenusa 5. Encuentra las razones trigonométricas del ángulo θ."
              />
            </div>
            <div className="flex flex-col md:flex-row gap-4 items-end">
              <div className="space-y-2 flex-1 w-full">
                <Label htmlFor="angle">Ángulo (θ)</Label>
                <Input 
                  id="angle" 
                  type="number" 
                  value={angle} 
                  onChange={(e) => setAngle(e.target.value)} 
                  placeholder="Ej: 45"
                  className="font-mono text-lg"
                />
              </div>
              <div className="space-y-2 w-full md:w-auto">
                <Label>Unidad</Label>
                <Tabs value={unit} onValueChange={(v) => setUnit(v as "deg" | "rad")} className="w-full">
                  <TabsList className="grid grid-cols-2 w-full md:w-[200px]">
                    <TabsTrigger value="deg">Grados (°)</TabsTrigger>
                    <TabsTrigger value="rad">Radianes</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
              <Button onClick={calculate} className="w-full md:w-auto px-8" size="lg">
                Calcular
              </Button>
            </div>
          </CardContent>
        </Card>

        <AnimatePresence>
          {results && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold mt-8 mb-4">Solución Paso a Paso</h2>
              <div className="grid gap-4 md:grid-cols-2">
                {results.map((step: any, index: number) => (
                  <motion.div
                    key={step.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.15 }}
                  >
                    <Card className="h-full border-primary/20 bg-card/50">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base text-primary flex items-center gap-2">
                          <span className="flex items-center justify-center bg-primary text-primary-foreground rounded-full w-6 h-6 text-xs">
                            {step.id}
                          </span>
                          {step.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="text-sm">
                        {typeof step.content === 'string' ? (
                          <p className="whitespace-pre-wrap">{step.content}</p>
                        ) : (
                          step.content
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </Layout>
  );
}