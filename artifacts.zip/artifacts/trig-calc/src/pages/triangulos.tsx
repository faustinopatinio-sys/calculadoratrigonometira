import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { solveTriangle, TriangleType, TriangleResult } from "@/lib/triangle-solver";
import { motion, AnimatePresence } from "framer-motion";

export default function Triangulos() {
  const [type, setType] = useState<TriangleType>("SSS");
  const [inputs, setInputs] = useState({ a: "", b: "", c: "", A: "", B: "", C: "" });
  const [result, setResult] = useState<TriangleResult | null>(null);

  const calculate = () => {
    const parsed = {
      type,
      a: parseFloat(inputs.a) || undefined,
      b: parseFloat(inputs.b) || undefined,
      c: parseFloat(inputs.c) || undefined,
      A: parseFloat(inputs.A) || undefined,
      B: parseFloat(inputs.B) || undefined,
      C: parseFloat(inputs.C) || undefined,
    };
    
    setResult(solveTriangle(parsed));
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Resolución de Triángulos</h1>
          <p className="text-muted-foreground mt-2">Resuelve triángulos oblicuángulos usando Ley de Senos y Cosenos.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Configuración</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Caso</Label>
              <Tabs value={type} onValueChange={(v) => setType(v as TriangleType)} className="w-full mt-2">
                <TabsList className="grid grid-cols-5 w-full">
                  <TabsTrigger value="SSS">L-L-L</TabsTrigger>
                  <TabsTrigger value="SAS">L-A-L</TabsTrigger>
                  <TabsTrigger value="AAS">A-A-L</TabsTrigger>
                  <TabsTrigger value="ASA">A-L-A</TabsTrigger>
                  <TabsTrigger value="SSA">L-L-A</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {['a', 'b', 'c', 'A', 'B', 'C'].map((k) => (
                <div key={k} className="space-y-2">
                  <Label htmlFor={k}>{['A','B','C'].includes(k) ? `Ángulo ${k} (°)` : `Lado ${k}`}</Label>
                  <Input 
                    id={k} 
                    type="number"
                    value={inputs[k as keyof typeof inputs]}
                    onChange={(e) => setInputs({...inputs, [k]: e.target.value})}
                    placeholder={`Valor de ${k}`}
                  />
                </div>
              ))}
            </div>
            
            <Button onClick={calculate} className="w-full">
              Resolver Triángulo
            </Button>
          </CardContent>
        </Card>

        <AnimatePresence>
          {result && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold mt-8 mb-4">Solución</h2>
              {result.noSolution ? (
                 <Card className="bg-destructive/10 border-destructive/20"><CardContent className="p-4 text-destructive">No hay solución válida.</CardContent></Card>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Valores Finales</CardTitle>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 gap-4">
                      <div>Lado a = {result.a}</div>
                      <div>Ángulo A = {result.A}°</div>
                      <div>Lado b = {result.b}</div>
                      <div>Ángulo B = {result.B}°</div>
                      <div>Lado c = {result.c}</div>
                      <div>Ángulo C = {result.C}°</div>
                    </CardContent>
                  </Card>
                  
                  <div className="space-y-4">
                    {result.steps.map((step, idx) => (
                      <motion.div key={step.id} initial={{opacity: 0, x: 20}} animate={{opacity: 1, x: 0}} transition={{delay: idx*0.1}}>
                        <Card className="border-primary/20 bg-card/50">
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base text-primary">{step.title}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="whitespace-pre-wrap font-mono text-sm">{step.content}</p>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </AnimatePresence>
      </div>
    </Layout>
  );
}
