import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Razones from "@/pages/razones";
import Identidades from "@/pages/identidades";
import Triangulos from "@/pages/triangulos";
import Ejercicios from "@/pages/ejercicios";

const queryClient = new QueryClient();

if (typeof document !== "undefined") {
  document.documentElement.classList.add("dark");
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/razones" component={Razones} />
      <Route path="/identidades" component={Identidades} />
      <Route path="/triangulos" component={Triangulos} />
      <Route path="/ejercicios" component={Ejercicios} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
